lang=$1
scp root@10.134.88.171:/search/liuxiaolong/lxl_makeDict/${lang}_language/word_origin_classify/*AllCharacter.txt ./${lang}.txt
