#sh format_transform_hadoop.sh facebook
#sh format_transform_hadoop.sh instagram
#sh format_transform_hadoop.sh twitter
#sh format_transform_hadoop.sh vk

#sh format_transform_hadoop.sh dbg_pinjie
#sh format_transform_hadoop.sh dbg_st

sh format_transform_hadoop.dbg_st.restrict_data.sh dbg_st tl
