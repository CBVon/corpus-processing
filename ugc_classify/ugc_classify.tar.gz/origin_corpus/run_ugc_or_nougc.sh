#proccessing ru
#python ugc_or_nougc_by_label.py facebook ru
#python ugc_or_nougc_by_label.py instagram ru
#python ugc_or_nougc_by_label.py twitter ru
#python ugc_or_nougc_by_label.py vk ru

#proccessing pt
#python ugc_or_nougc_by_label.py facebook pt
#python ugc_or_nougc_by_label.py instagram pt
#python ugc_or_nougc_by_label.py twitter pt

#proccessing de
python ugc_or_nougc_by_label.py facebook de
python ugc_or_nougc_by_label.py instagram de
python ugc_or_nougc_by_label.py twitter de
