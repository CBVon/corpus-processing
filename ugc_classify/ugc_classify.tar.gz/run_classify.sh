#datatype="facebook"
#datatype="instagram"
datatype="twitter"
#datatype="vk"

#lang="es"
#lang="ru"
#lang="pt"
lang="fr"

sh ugc_classify_hadoop.sh ${datatype} ${lang}
