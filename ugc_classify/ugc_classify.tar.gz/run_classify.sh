#ugc_classify_hadoop.sh: filter_map.py: path_pre = ?

datatype="facebook"
#datatype="instagram"
#datatype="twitter"
#datatype="vk"

#lang="es"
#lang="ru"
#lang="pt"
#lang="fr"
lang="de"

sh ugc_classify_hadoop.sh ${datatype} ${lang}
