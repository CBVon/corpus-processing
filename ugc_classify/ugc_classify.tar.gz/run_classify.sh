#datatype="facebook"
#datatype="instagram"
datatype="twitter"
#datatype="vk"

#lang="es"
lang="ru"

sh ugc_classify_hadoop.sh ${datatype} ${lang}
