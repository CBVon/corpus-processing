#coding: utf-8
#no-use


import numpy as np


a = np.array([1])
